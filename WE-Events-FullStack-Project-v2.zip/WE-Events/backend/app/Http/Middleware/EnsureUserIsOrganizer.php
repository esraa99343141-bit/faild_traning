<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureUserIsOrganizer
{
    public function handle(Request $request, Closure $next): Response
    {
        if (! $request->user() || $request->user()->role !== 'organizer') {
            return response()->json([
                'message' => 'Forbidden. Only users with the organizer role can perform this action.'
            ], 403);
        }

        return $next($request);
    }
}
