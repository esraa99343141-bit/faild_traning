<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\WorkshopResource;
use App\Models\Workshop;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class WorkshopController extends Controller
{
    public function index(): AnonymousResourceCollection
    {
        $workshops = Workshop::with('organizer')
            ->withCount('registrations')
            ->orderBy('event_date', 'asc')
            ->get();

        return WorkshopResource::collection($workshops);
    }

    public function show(Workshop $workshop): WorkshopResource
    {
        $workshop->load('organizer')->loadCount('registrations');

        return new WorkshopResource($workshop);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'title' => ['required', 'string', 'max:255'],
            'description' => ['required', 'string'],
            'instructor' => ['required', 'string', 'max:255'],
            'location' => ['required', 'string', 'max:255'],
            'event_date' => ['required', 'date'],
            'capacity' => ['required', 'integer', 'min:1', 'max:1000'],
        ]);

        $workshop = $request->user()->organizedWorkshops()->create($validated);
        $workshop->load('organizer')->loadCount('registrations');

        return response()->json([
            'message' => 'Workshop created successfully.',
            'data' => new WorkshopResource($workshop),
        ], 201);
    }

    public function update(Request $request, Workshop $workshop): JsonResponse
    {
        if ($workshop->organizer_id !== $request->user()->id) {
            return response()->json([
                'message' => 'Forbidden. You can only edit workshops you created.'
            ], 403);
        }

        $validated = $request->validate([
            'title' => ['sometimes', 'required', 'string', 'max:255'],
            'description' => ['sometimes', 'required', 'string'],
            'instructor' => ['sometimes', 'required', 'string', 'max:255'],
            'location' => ['sometimes', 'required', 'string', 'max:255'],
            'event_date' => ['sometimes', 'required', 'date'],
            'capacity' => ['sometimes', 'required', 'integer', 'min:1', 'max:1000'],
        ]);

        $workshop->update($validated);
        $workshop->load('organizer')->loadCount('registrations');

        return response()->json([
            'message' => 'Workshop updated successfully.',
            'data' => new WorkshopResource($workshop),
        ], 200);
    }

    public function destroy(Request $request, Workshop $workshop): JsonResponse
    {
        if ($workshop->organizer_id !== $request->user()->id) {
            return response()->json([
                'message' => 'Forbidden. You can only delete workshops you created.'
            ], 403);
        }

        $workshop->delete();

        return response()->json([
            'message' => 'Workshop deleted successfully.',
        ], 200);
    }
}
