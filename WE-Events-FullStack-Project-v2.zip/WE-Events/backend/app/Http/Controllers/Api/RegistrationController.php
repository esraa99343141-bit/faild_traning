<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\RegistrationResource;
use App\Models\Registration;
use App\Models\Workshop;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Illuminate\Support\Facades\Gate;

class RegistrationController extends Controller
{
    public function myRegistrations(Request $request): AnonymousResourceCollection
    {
        $registrations = $request->user()
            ->registrations()
            ->with(['user', 'workshop.organizer'])
            ->latest()
            ->get();

        return RegistrationResource::collection($registrations);
    }

    public function store(Request $request, Workshop $workshop): JsonResponse
    {
        $user = $request->user();

        if ($user->role !== 'student') {
            return response()->json([
                'message' => 'Forbidden. Only students can register for workshops.'
            ], 403);
        }

        $alreadyRegistered = Registration::where('user_id', $user->id)
            ->where('workshop_id', $workshop->id)
            ->exists();

        if ($alreadyRegistered) {
            return response()->json([
                'message' => 'You are already registered for this workshop.'
            ], 422);
        }

        if ($workshop->registrations()->count() >= $workshop->capacity) {
            return response()->json([
                'message' => 'This workshop has reached full capacity.'
            ], 422);
        }

        $registration = Registration::create([
            'user_id' => $user->id,
            'workshop_id' => $workshop->id,
            'status' => 'confirmed',
        ]);

        $registration->load(['user', 'workshop.organizer']);

        return response()->json([
            'message' => 'Successfully registered for the workshop!',
            'data' => new RegistrationResource($registration),
        ], 201);
    }

    public function destroy(Registration $registration): JsonResponse
    {
        if (Gate::denies('cancel-registration', $registration)) {
            return response()->json([
                'message' => 'Forbidden. You cannot cancel a registration that does not belong to you.'
            ], 403);
        }

        $registration->delete();

        return response()->json([
            'message' => 'Workshop registration canceled successfully.',
        ], 200);
    }
}
