<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class WorkshopResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        $enrolledCount = $this->registrations_count ?? $this->registrations()->count();

        return [
            'id' => $this->id,
            'title' => $this->title,
            'description' => $this->description,
            'instructor' => $this->instructor,
            'location' => $this->location,
            'event_date' => $this->event_date?->toISOString(),
            'formatted_date' => $this->event_date?->format('M d, Y - h:i A'),
            'capacity' => $this->capacity,
            'enrolled_count' => $enrolledCount,
            'available_seats' => max(0, $this->capacity - $enrolledCount),
            'organizer' => [
                'id' => $this->organizer?->id,
                'name' => $this->organizer?->name,
            ],
            'created_at' => $this->created_at?->toISOString(),
        ];
    }
}
