<?php

namespace App\Providers;

use App\Models\Registration;
use App\Models\User;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        Gate::define('cancel-registration', function (User $user, Registration $registration) {
            return $user->id === $registration->user_id;
        });
    }
}
