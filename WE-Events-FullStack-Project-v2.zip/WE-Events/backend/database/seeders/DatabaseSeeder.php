<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Workshop;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $organizer = User::create([
            'name' => 'Dr. Ahmed Hassan',
            'email' => 'organizer@we-events.com',
            'password' => Hash::make('password123'),
            'role' => 'organizer',
        ]);

        User::create([
            'name' => 'Sara Mahmoud',
            'email' => 'student@we-events.com',
            'password' => Hash::make('password123'),
            'role' => 'student',
        ]);

        Workshop::create([
            'organizer_id' => $organizer->id,
            'title' => 'Building RESTful APIs with Laravel 11',
            'description' => 'Learn how to architect clean, secure RESTful APIs using Eloquent relationships, API Resources, Sanctum tokens, and custom middleware.',
            'instructor' => 'Dr. Ahmed Hassan',
            'location' => 'Computer Lab A - Building 2',
            'event_date' => now()->addDays(5)->setTime(10, 0),
            'capacity' => 25,
        ]);

        Workshop::create([
            'organizer_id' => $organizer->id,
            'title' => 'Modern React SPA & State Management',
            'description' => 'Hands-on workshop covering React Router v6, Context API for authentication, custom hooks, and proper useEffect cleanup patterns.',
            'instructor' => 'Eng. Nour El-Din',
            'location' => 'Innovation Hall - Room 304',
            'event_date' => now()->addDays(10)->setTime(13, 30),
            'capacity' => 30,
        ]);

        Workshop::create([
            'organizer_id' => $organizer->id,
            'title' => 'Database Optimization & Indexing in MySQL',
            'description' => 'Deep dive into relational schema design, foreign key constraints, composite indexes, and query execution plans.',
            'instructor' => 'Eng. Karim Tarek',
            'location' => 'Computer Lab B - Building 1',
            'event_date' => now()->addDays(14)->setTime(11, 0),
            'capacity' => 20,
        ]);
    }
}
