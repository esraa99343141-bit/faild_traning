# WE-Events: Full-Stack Event & Workshop Registration System

A complete full-stack web application built with **Laravel (RESTful API + Sanctum)** and **React (Vite + React Router + Axios + Bootstrap 5)**.

## Project Structure
- `backend/` - Laravel RESTful API (Models, Migrations, Seeders, Custom Middleware, Gates, API Resources, Controllers, Routes)
- `frontend/` - React Single-Page Application (Context API, Protected Routes, `useEffect` with cleanup, Role-based Dashboards)

---

## Setup & Installation Instructions

### 1. Database Setup (XAMPP / MySQL)
1. Start **Apache** and **MySQL** in XAMPP.
2. Open `http://localhost/phpmyadmin` and create a new database named `we_events`.

### 2. Backend Setup (Laravel API - Port 8000)
```bash
composer create-project laravel/laravel we-events-backend
cd we-events-backend
php artisan install:api
```
Copy all files from the `backend/` folder into your Laravel project root (overwriting matching files), configure `.env`:
```env
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=we_events
DB_USERNAME=root
DB_PASSWORD=
```
Then run migrations, seeders, and start the server:
```bash
php artisan migrate:fresh --seed
php artisan serve
```
The API will run at `http://127.0.0.1:8000`.

### 3. Frontend Setup (React + Vite - Port 5173)
Open a **second terminal window**:
```bash
npm create vite@latest we-events-frontend -- --template react
cd we-events-frontend
npm install axios react-router-dom bootstrap
```
Copy all files from the `frontend/` folder into your React project root, then start the dev server:
```bash
npm run dev
```
The frontend will run at `http://localhost:5173`.

---

## Test Accounts (Created by DatabaseSeeder)
| Role | Email | Password |
| :--- | :--- | :--- |
| **Organizer** | `organizer@we-events.com` | `password123` |
| **Student** | `student@we-events.com` | `password123` |

---

## API Endpoints Summary
| Method | Endpoint | Access | Description |
| :--- | :--- | :--- | :--- |
| `POST` | `/api/register` | Public | Register a new user (`student` or `organizer`) |
| `POST` | `/api/login` | Public | Login and receive Bearer token |
| `POST` | `/api/logout` | Auth | Revoke current access token |
| `GET` | `/api/user` | Auth | Get authenticated user profile |
| `GET` | `/api/workshops` | Public | List all workshops |
| `GET` | `/api/workshops/{id}` | Public | View single workshop details |
| `POST` | `/api/workshops` | Organizer | Create a new workshop |
| `PUT` | `/api/workshops/{id}` | Organizer | Update an existing workshop |
| `DELETE` | `/api/workshops/{id}` | Organizer | Delete a workshop |
| `GET` | `/api/my-registrations` | Student | List logged-in student's registrations |
| `POST` | `/api/workshops/{id}/register` | Student | Enroll in a workshop |
| `DELETE` | `/api/registrations/{id}` | Student (Owner via Gate) | Cancel own registration |
