import React from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Navbar = () => {
  const { user, isAuthenticated, isOrganizer, isStudent, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm mb-4">
      <div className="container">
        <Link className="navbar-brand fw-bold" to="/">
          WE-Events
        </Link>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#mainNavbar"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="mainNavbar">
          <ul className="navbar-nav me-auto mb-2 mb-lg-0">
            <li className="nav-item">
              <NavLink className="nav-link" to="/" end>
                Workshops
              </NavLink>
            </li>

            {isAuthenticated && isStudent && (
              <li className="nav-item">
                <NavLink className="nav-link" to="/student/dashboard">
                  My Registrations
                </NavLink>
              </li>
            )}

            {isAuthenticated && isOrganizer && (
              <li className="nav-item">
                <NavLink className="nav-link" to="/organizer/dashboard">
                  Organizer Dashboard
                </NavLink>
              </li>
            )}
          </ul>

          <div className="d-flex align-items-center gap-2">
            {!isAuthenticated ? (
              <>
                <NavLink className="btn btn-outline-light btn-sm" to="/login">
                  Login
                </NavLink>
                <NavLink className="btn btn-light btn-sm text-primary fw-semibold" to="/register">
                  Register
                </NavLink>
              </>
            ) : (
              <>
                <span className="text-white small me-2">
                  {user.name}{' '}
                  <span className="badge bg-light text-primary text-uppercase">
                    {user.role}
                  </span>
                </span>
                <button className="btn btn-outline-light btn-sm" onClick={handleLogout}>
                  Logout
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
