import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axiosClient from '../api/axiosClient';

const WorkshopsList = () => {
  const [workshops, setWorkshops] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const controller = new AbortController();

    const fetchWorkshops = async () => {
      try {
        setLoading(true);
        setError('');
        const response = await axiosClient.get('/workshops', {
          signal: controller.signal,
        });
        setWorkshops(response.data.data || []);
      } catch (err) {
        if (err.name !== 'CanceledError' && err.code !== 'ERR_CANCELED') {
          setError(
            err.response?.data?.message ||
              'Failed to load workshops. Please make sure the Laravel server is running.'
          );
        }
      } finally {
        setLoading(false);
      }
    };

    fetchWorkshops();

    return () => controller.abort();
  }, []);

  if (loading) {
    return (
      <div className="text-center my-5">
        <div className="spinner-border text-primary" role="status" />
        <p className="mt-2 text-muted">Loading upcoming workshops...</p>
      </div>
    );
  }

  return (
    <div className="container">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h2 className="fw-bold mb-1">Upcoming Workshops & Events</h2>
          <p className="text-muted mb-0">Browse technical workshops and reserve your seat.</p>
        </div>
      </div>

      {error && (
        <div className="alert alert-danger" role="alert">
          {error}
        </div>
      )}

      {!error && workshops.length === 0 ? (
        <div className="alert alert-info">No workshops scheduled yet.</div>
      ) : (
        <div className="row g-4">
          {workshops.map((workshop) => (
            <div className="col-md-6 col-lg-4" key={workshop.id}>
              <div className="card h-100 shadow-sm border-0">
                <div className="card-body d-flex flex-column">
                  <div className="d-flex justify-content-between align-items-start mb-2">
                    <span className="badge bg-primary-subtle text-primary">
                      {workshop.formatted_date}
                    </span>
                    <span
                      className={`badge ${
                        workshop.available_seats > 0 ? 'bg-success' : 'bg-danger'
                      }`}
                    >
                      {workshop.available_seats} / {workshop.capacity} seats left
                    </span>
                  </div>

                  <h5 className="card-title fw-bold mt-2">{workshop.title}</h5>
                  <p className="card-text text-muted small flex-grow-1">
                    {workshop.description.length > 120
                      ? `${workshop.description.slice(0, 120)}...`
                      : workshop.description}
                  </p>

                  <ul className="list-unstyled small text-secondary mb-3">
                    <li>
                      <strong>Instructor:</strong> {workshop.instructor}
                    </li>
                    <li>
                      <strong>Location:</strong> {workshop.location}
                    </li>
                  </ul>

                  <Link
                    to={`/workshops/${workshop.id}`}
                    className="btn btn-outline-primary w-100 mt-auto"
                  >
                    View Details & Register
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default WorkshopsList;
