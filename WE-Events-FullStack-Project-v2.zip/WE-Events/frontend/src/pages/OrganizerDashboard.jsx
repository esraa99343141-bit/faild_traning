import React, { useState, useEffect } from 'react';
import axiosClient from '../api/axiosClient';
import { useAuth } from '../context/AuthContext';

const OrganizerDashboard = () => {
  const { user } = useAuth();
  const [workshops, setWorkshops] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const [form, setForm] = useState({
    title: '',
    description: '',
    instructor: '',
    location: '',
    event_date: '',
    capacity: 25,
  });

  useEffect(() => {
    const controller = new AbortController();

    const fetchWorkshops = async () => {
      try {
        setLoading(true);
        const response = await axiosClient.get('/workshops', {
          signal: controller.signal,
        });
        setWorkshops(response.data.data || []);
      } catch (err) {
        if (err.name !== 'CanceledError' && err.code !== 'ERR_CANCELED') {
          setError('Failed to load workshops.');
        }
      } finally {
        setLoading(false);
      }
    };

    fetchWorkshops();

    return () => controller.abort();
  }, []);

  const handleChange = (e) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleCreate = async (e) => {
    e.preventDefault();
    setError('');
    setSuccessMsg('');
    setSubmitting(true);

    try {
      const response = await axiosClient.post('/workshops', form);
      setWorkshops((prev) => [...prev, response.data.data]);
      setSuccessMsg('Workshop published successfully!');
      setForm({
        title: '',
        description: '',
        instructor: '',
        location: '',
        event_date: '',
        capacity: 25,
      });
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to publish workshop.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this workshop permanently?')) return;

    try {
      setError('');
      setSuccessMsg('');
      await axiosClient.delete(`/workshops/${id}`);
      setWorkshops((prev) => prev.filter((w) => w.id !== id));
      setSuccessMsg('Workshop deleted.');
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to delete workshop.');
    }
  };

  return (
    <div className="container">
      <h2 className="fw-bold mb-4">Organizer Dashboard</h2>

      {error && <div className="alert alert-danger">{error}</div>}
      {successMsg && <div className="alert alert-success">{successMsg}</div>}

      <div className="row g-4">
        <div className="col-lg-5">
          <div className="card shadow-sm border-0">
            <div className="card-body p-4">
              <h5 className="fw-bold mb-3">Publish New Workshop</h5>
              <form onSubmit={handleCreate}>
                <div className="mb-3">
                  <label className="form-label">Workshop Title</label>
                  <input
                    type="text"
                    name="title"
                    className="form-control"
                    value={form.title}
                    onChange={handleChange}
                    required
                  />
                </div>

                <div className="mb-3">
                  <label className="form-label">Instructor Name</label>
                  <input
                    type="text"
                    name="instructor"
                    className="form-control"
                    value={form.instructor}
                    onChange={handleChange}
                    required
                  />
                </div>

                <div className="mb-3">
                  <label className="form-label">Location</label>
                  <input
                    type="text"
                    name="location"
                    className="form-control"
                    value={form.location}
                    onChange={handleChange}
                    required
                  />
                </div>

                <div className="row mb-3">
                  <div className="col-7">
                    <label className="form-label">Date & Time</label>
                    <input
                      type="datetime-local"
                      name="event_date"
                      className="form-control"
                      value={form.event_date}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  <div className="col-5">
                    <label className="form-label">Capacity</label>
                    <input
                      type="number"
                      name="capacity"
                      className="form-control"
                      min="1"
                      max="1000"
                      value={form.capacity}
                      onChange={handleChange}
                      required
                    />
                  </div>
                </div>

                <div className="mb-3">
                  <label className="form-label">Description</label>
                  <textarea
                    name="description"
                    className="form-control"
                    rows="3"
                    value={form.description}
                    onChange={handleChange}
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="btn btn-primary w-100"
                  disabled={submitting}
                >
                  {submitting ? 'Publishing...' : 'Publish Workshop'}
                </button>
              </form>
            </div>
          </div>
        </div>

        <div className="col-lg-7">
          <div className="card shadow-sm border-0">
            <div className="card-body p-4">
              <h5 className="fw-bold mb-3">Published Workshops</h5>

              {loading ? (
                <div className="text-center my-4">
                  <div className="spinner-border text-primary" role="status" />
                </div>
              ) : workshops.length === 0 ? (
                <p className="text-muted">No workshops found.</p>
              ) : (
                <div className="table-responsive">
                  <table className="table align-middle">
                    <thead className="table-light">
                      <tr>
                        <th>Title</th>
                        <th>Date</th>
                        <th>Enrolled</th>
                        <th className="text-end">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {workshops.map((w) => (
                        <tr key={w.id}>
                          <td>
                            <div className="fw-semibold">{w.title}</div>
                            <small className="text-muted">{w.location}</small>
                          </td>
                          <td className="small">{w.formatted_date}</td>
                          <td>
                            <span className="badge bg-info text-dark">
                              {w.enrolled_count} / {w.capacity}
                            </span>
                          </td>
                          <td className="text-end">
                            {w.organizer?.id === user?.id ? (
                              <button
                                className="btn btn-outline-danger btn-sm"
                                onClick={() => handleDelete(w.id)}
                              >
                                Delete
                              </button>
                            ) : (
                              <span className="text-muted small">Other Organizer</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrganizerDashboard;
