import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axiosClient from '../api/axiosClient';

const StudentDashboard = () => {
  const [registrations, setRegistrations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [feedback, setFeedback] = useState('');

  useEffect(() => {
    const controller = new AbortController();

    const fetchMyRegistrations = async () => {
      try {
        setLoading(true);
        const response = await axiosClient.get('/my-registrations', {
          signal: controller.signal,
        });
        setRegistrations(response.data.data || []);
      } catch (err) {
        if (err.name !== 'CanceledError' && err.code !== 'ERR_CANCELED') {
          setError(err.response?.data?.message || 'Failed to load your registrations.');
        }
      } finally {
        setLoading(false);
      }
    };

    fetchMyRegistrations();

    return () => controller.abort();
  }, []);

  const handleCancel = async (registrationId) => {
    if (!window.confirm('Are you sure you want to cancel this registration?')) return;

    try {
      setFeedback('');
      await axiosClient.delete(`/registrations/${registrationId}`);
      setRegistrations((prev) => prev.filter((item) => item.id !== registrationId));
      setFeedback('Registration canceled successfully.');
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to cancel registration.');
    }
  };

  if (loading) {
    return (
      <div className="text-center my-5">
        <div className="spinner-border text-primary" role="status" />
      </div>
    );
  }

  return (
    <div className="container">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2 className="fw-bold mb-0">My Enrolled Workshops</h2>
        <Link to="/" className="btn btn-primary btn-sm">
          Browse More Workshops
        </Link>
      </div>

      {error && <div className="alert alert-danger">{error}</div>}
      {feedback && <div className="alert alert-success">{feedback}</div>}

      {registrations.length === 0 ? (
        <div className="card border-0 shadow-sm p-4 text-center">
          <p className="text-muted mb-3">You have not enrolled in any workshops yet.</p>
          <div>
            <Link to="/" className="btn btn-outline-primary">
              Explore Workshops
            </Link>
          </div>
        </div>
      ) : (
        <div className="table-responsive bg-white rounded shadow-sm p-3">
          <table className="table table-hover align-middle mb-0">
            <thead className="table-light">
              <tr>
                <th>Workshop</th>
                <th>Instructor</th>
                <th>Date & Time</th>
                <th>Location</th>
                <th>Status</th>
                <th className="text-end">Action</th>
              </tr>
            </thead>
            <tbody>
              {registrations.map((reg) => (
                <tr key={reg.id}>
                  <td className="fw-semibold">
                    <Link to={`/workshops/${reg.workshop?.id}`} className="text-decoration-none">
                      {reg.workshop?.title}
                    </Link>
                  </td>
                  <td>{reg.workshop?.instructor}</td>
                  <td>{reg.workshop?.formatted_date}</td>
                  <td>{reg.workshop?.location}</td>
                  <td>
                    <span className="badge bg-success text-uppercase">{reg.status}</span>
                  </td>
                  <td className="text-end">
                    <button
                      className="btn btn-outline-danger btn-sm"
                      onClick={() => handleCancel(reg.id)}
                    >
                      Cancel Registration
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default StudentDashboard;
