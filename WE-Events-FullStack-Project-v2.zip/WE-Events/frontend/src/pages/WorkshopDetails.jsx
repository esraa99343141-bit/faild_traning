import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import axiosClient from '../api/axiosClient';
import { useAuth } from '../context/AuthContext';

const WorkshopDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { isAuthenticated, isStudent } = useAuth();

  const [workshop, setWorkshop] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [actionMsg, setActionMsg] = useState({ type: '', text: '' });
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    const controller = new AbortController();

    const fetchWorkshopDetails = async () => {
      try {
        setLoading(true);
        setError('');
        const response = await axiosClient.get(`/workshops/${id}`, {
          signal: controller.signal,
        });
        setWorkshop(response.data.data);
      } catch (err) {
        if (err.name !== 'CanceledError' && err.code !== 'ERR_CANCELED') {
          setError(
            err.response?.status === 404
              ? 'Workshop not found.'
              : err.response?.data?.message || 'Error fetching workshop details.'
          );
        }
      } finally {
        setLoading(false);
      }
    };

    fetchWorkshopDetails();

    return () => controller.abort();
  }, [id]);

  const handleEnroll = async () => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }

    try {
      setSubmitting(true);
      setActionMsg({ type: '', text: '' });
      const response = await axiosClient.post(`/workshops/${id}/register`);
      setActionMsg({
        type: 'success',
        text: response.data.message || 'Successfully registered!',
      });
      const updated = await axiosClient.get(`/workshops/${id}`);
      setWorkshop(updated.data.data);
    } catch (err) {
      setActionMsg({
        type: 'danger',
        text: err.response?.data?.message || 'Registration failed.',
      });
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="text-center my-5">
        <div className="spinner-border text-primary" role="status" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="container">
        <div className="alert alert-danger">{error}</div>
        <Link to="/" className="btn btn-secondary">
          Back to Workshops
        </Link>
      </div>
    );
  }

  return (
    <div className="container">
      <Link to="/" className="btn btn-link ps-0 mb-3 text-decoration-none">
        &larr; Back to All Workshops
      </Link>

      <div className="card shadow-sm border-0">
        <div className="card-body p-4">
          <div className="d-flex flex-wrap justify-content-between align-items-center mb-3">
            <h2 className="fw-bold mb-0">{workshop.title}</h2>
            <span
              className={`badge fs-6 ${
                workshop.available_seats > 0 ? 'bg-success' : 'bg-danger'
              }`}
            >
              {workshop.available_seats} seats available
            </span>
          </div>

          <p className="lead text-secondary">{workshop.description}</p>
          <hr />

          <div className="row mb-4">
            <div className="col-md-6">
              <p className="mb-2">
                <strong>Instructor:</strong> {workshop.instructor}
              </p>
              <p className="mb-2">
                <strong>Organizer:</strong> {workshop.organizer?.name}
              </p>
            </div>
            <div className="col-md-6">
              <p className="mb-2">
                <strong>Date & Time:</strong> {workshop.formatted_date}
              </p>
              <p className="mb-2">
                <strong>Location:</strong> {workshop.location}
              </p>
              <p className="mb-2">
                <strong>Capacity:</strong> {workshop.enrolled_count} / {workshop.capacity} enrolled
              </p>
            </div>
          </div>

          {actionMsg.text && (
            <div className={`alert alert-${actionMsg.type}`} role="alert">
              {actionMsg.text}
            </div>
          )}

          {!isAuthenticated && (
            <div className="alert alert-warning">
              Please <Link to="/login">login as a student</Link> to register for this workshop.
            </div>
          )}

          {isAuthenticated && isStudent && (
            <button
              className="btn btn-primary btn-lg"
              onClick={handleEnroll}
              disabled={submitting || workshop.available_seats === 0}
            >
              {submitting
                ? 'Enrolling...'
                : workshop.available_seats === 0
                ? 'Workshop Full'
                : 'Enroll in Workshop'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default WorkshopDetails;
