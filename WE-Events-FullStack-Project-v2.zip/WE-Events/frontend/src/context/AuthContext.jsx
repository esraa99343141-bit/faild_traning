import React, { createContext, useContext, useState, useEffect } from 'react';
import axiosClient from '../api/axiosClient';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    const savedUser = localStorage.getItem('we_user');
    return savedUser ? JSON.parse(savedUser) : null;
  });
  const [token, setToken] = useState(() => localStorage.getItem('we_token') || null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;

    const verifySession = async () => {
      if (!token) {
        if (isMounted) setLoading(false);
        return;
      }

      try {
        const response = await axiosClient.get('/user');
        if (isMounted) {
          setUser(response.data.user);
          localStorage.setItem('we_user', JSON.stringify(response.data.user));
        }
      } catch (err) {
        if (isMounted) {
          setUser(null);
          setToken(null);
          localStorage.removeItem('we_token');
          localStorage.removeItem('we_user');
        }
      } finally {
        if (isMounted) setLoading(false);
      }
    };

    verifySession();

    return () => {
      isMounted = false;
    };
  }, [token]);

  const login = async (email, password) => {
    const response = await axiosClient.post('/login', { email, password });
    const { user: loggedInUser, token: accessToken } = response.data;
    setUser(loggedInUser);
    setToken(accessToken);
    localStorage.setItem('we_token', accessToken);
    localStorage.setItem('we_user', JSON.stringify(loggedInUser));
    return loggedInUser;
  };

  const register = async (formData) => {
    const response = await axiosClient.post('/register', formData);
    const { user: createdUser, token: accessToken } = response.data;
    setUser(createdUser);
    setToken(accessToken);
    localStorage.setItem('we_token', accessToken);
    localStorage.setItem('we_user', JSON.stringify(createdUser));
    return createdUser;
  };

  const logout = async () => {
    try {
      await axiosClient.post('/logout');
    } catch (err) {
      // Ignore error if token already expired
    } finally {
      setUser(null);
      setToken(null);
      localStorage.removeItem('we_token');
      localStorage.removeItem('we_user');
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        loading,
        isAuthenticated: Boolean(user && token),
        isOrganizer: user?.role === 'organizer',
        isStudent: user?.role === 'student',
        login,
        register,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
